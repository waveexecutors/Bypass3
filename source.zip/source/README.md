# Bypass — Fabric 1.21.11

A client-side SMP utility mod named **Bypass**, with a modern category ClickGUI (Right Shift), an inventory item selector for `/sell`, basic crop planting, local ore scanning, storage radar, movement helpers, alerts, and an accessory selection/preview screen.

## Build it on GitHub (no PC / no local compiler needed)

1. Extract this ZIP on your phone.
2. On GitHub, create a new repository named `Bypass`.
3. Open the repository, choose **Add file → Upload files**, and upload the *contents* of this folder (including the hidden `.github` folder). Commit the files to the `main` branch.
4. Make sure `.github/workflows/build.yml` is present in the repository. If your phone's upload page hides dot-folders, create a new file on GitHub with that exact path and paste in the workflow contents from this ZIP. Then open **Actions**; **Build Bypass Fabric Mod** should start after the commit. You can also open it and press **Run workflow**.
5. Open the completed workflow run and scroll to **Artifacts**. Download `Bypass-Fabric-1.21.11` and extract it. The artifact contains `bypass-1.0.0.jar`.
6. Put that JAR in the Minecraft `mods` folder in a Fabric 1.21.11 instance. Install Fabric API for 1.21.11 as well.

GitHub Actions performs the Gradle build; you do not need to install Java or Gradle on your phone.

## Included features

- **ClickGUI:** Right Shift opens Bypass. Categories: Mining, Farming, SMP, Movement, Misc.
- **Ore Scanner:** periodically scans a small area around the player and reports the nearest known ore coordinates.
- **Auto Farm Planter:** plants one crop at a time on nearby existing farmland. A supported seed/crop item must be in the hotbar. It does not excavate, till soil, or create water channels.
- **Base / Storage Radar:** looks for nearby chest, trapped chest, barrel, and selected shulker-box blocks in client-loaded world data, then reports the nearest match.
- **Auto Sell:** choose an item directly from your inventory. While enabled, the mod sends `sell <item_id>` every 40 ticks (about two seconds), but only while at least one matching item remains in your inventory.
- **Auto Sprint:** holds sprint while the forward key is pressed and the player is not sneaking.
- **Coordinates HUD** and **Totem Alert**.
- **Accessory Studio:** full-screen tabs for wing styles, bandanas, masks, and hats. Multiple selections across categories can be saved together in `config/bypass.properties`. The screen shows a rotatable player-model preview and lists the selected styles.

## Important technical limits

- **No client mod can reveal data that a server never sends.** If an SMP anti-X-ray replaces hidden ores with fake blocks in the chunk data, this Ore Scanner cannot see the real ore locations. It only reads block states available to the client; it is not an anti-X-ray exploit.
- The Storage Radar is a nearby loaded-block scan, not a whole-world or cross-dimension base locator. It can find ordinary storage blocks, not prove that a location is a player base.
- The Auto Sell command format is server-specific. This build sends `sell <item_id>` without the leading slash. A server may instead require a different argument format, a permission, or a confirmation GUI; Bypass cannot override those server rules.
- Accessory selections are saved in the full-screen studio. The preview shows your player model, while selected styles are listed beside it; the styles are **not drawn onto the preview model** and are not attached to the live in-world player renderer or visible to other players in this build.
- Auto-farming uses normal Minecraft block interactions. It will not bypass reach, server checks, missing items, or protection plugins.

## Toolchain

- Minecraft: `1.21.11`
- Java: `21`
- Fabric Loader: `0.18.1` minimum
- Fabric API: `0.141.1+1.21.11`
- Fabric Loom: `1.14-SNAPSHOT`
- Yarn mappings: `1.21.11+build.6`

The version values are centralized in `gradle.properties`.
