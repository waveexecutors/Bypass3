package com.toodoo.bypass;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.Properties;
import java.util.Set;

/** Small, human-readable config stored in config/bypass.properties. */
public final class BypassConfig {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("bypass.properties");

    public static boolean oreScanner = false;
    public static boolean autoFarm = false;
    public static boolean autoSell = false;
    public static boolean baseFinder = false;
    public static boolean autoSprint = false;
    public static boolean coordsHud = true;
    public static boolean totemAlert = true;
    public static String sellItem = "";

    private static final Set<String> WINGS = new LinkedHashSet<>();
    private static final Set<String> BANDANAS = new LinkedHashSet<>();
    private static final Set<String> MASKS = new LinkedHashSet<>();
    private static final Set<String> HATS = new LinkedHashSet<>();

    private BypassConfig() {}

    public static void load() {
        Properties p = new Properties();
        if (Files.exists(FILE)) {
            try (InputStream in = Files.newInputStream(FILE)) {
                p.load(in);
            } catch (IOException e) {
                BypassClient.LOGGER.error("Could not read Bypass config", e);
            }
        }

        oreScanner = Boolean.parseBoolean(p.getProperty("oreScanner", "false"));
        autoFarm = Boolean.parseBoolean(p.getProperty("autoFarm", "false"));
        autoSell = Boolean.parseBoolean(p.getProperty("autoSell", "false"));
        baseFinder = Boolean.parseBoolean(p.getProperty("baseFinder", "false"));
        autoSprint = Boolean.parseBoolean(p.getProperty("autoSprint", "false"));
        coordsHud = Boolean.parseBoolean(p.getProperty("coordsHud", "true"));
        totemAlert = Boolean.parseBoolean(p.getProperty("totemAlert", "true"));
        sellItem = p.getProperty("sellItem", "");

        loadSet(WINGS, p.getProperty("wings", ""));
        loadSet(BANDANAS, p.getProperty("bandanas", ""));
        loadSet(MASKS, p.getProperty("masks", ""));
        loadSet(HATS, p.getProperty("hats", ""));
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("oreScanner", Boolean.toString(oreScanner));
        p.setProperty("autoFarm", Boolean.toString(autoFarm));
        p.setProperty("autoSell", Boolean.toString(autoSell));
        p.setProperty("baseFinder", Boolean.toString(baseFinder));
        p.setProperty("autoSprint", Boolean.toString(autoSprint));
        p.setProperty("coordsHud", Boolean.toString(coordsHud));
        p.setProperty("totemAlert", Boolean.toString(totemAlert));
        p.setProperty("sellItem", sellItem);
        p.setProperty("wings", String.join(",", WINGS));
        p.setProperty("bandanas", String.join(",", BANDANAS));
        p.setProperty("masks", String.join(",", MASKS));
        p.setProperty("hats", String.join(",", HATS));

        try {
            Files.createDirectories(FILE.getParent());
            try (OutputStream out = Files.newOutputStream(FILE)) {
                p.store(out, "Bypass client configuration");
            }
        } catch (IOException e) {
            BypassClient.LOGGER.error("Could not save Bypass config", e);
        }
    }

    public static Set<String> getCosmetics(String category) {
        return switch (category) {
            case "WINGS" -> WINGS;
            case "BANDANAS" -> BANDANAS;
            case "MASKS" -> MASKS;
            case "HATS" -> HATS;
            default -> Set.of();
        };
    }

    public static void toggleCosmetic(String category, String option) {
        Set<String> set = switch (category) {
            case "WINGS" -> WINGS;
            case "BANDANAS" -> BANDANAS;
            case "MASKS" -> MASKS;
            case "HATS" -> HATS;
            default -> null;
        };
        if (set == null) return;
        if (!set.add(option)) set.remove(option);
        save();
    }

    private static void loadSet(Set<String> target, String raw) {
        target.clear();
        if (raw == null || raw.isBlank()) return;
        for (String value : raw.split(",")) {
            String trimmed = value.trim();
            if (!trimmed.isEmpty()) target.add(trimmed);
        }
    }
}
