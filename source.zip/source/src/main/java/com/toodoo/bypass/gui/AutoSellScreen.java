package com.toodoo.bypass.gui;

import com.toodoo.bypass.BypassConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.LinkedHashMap;
import java.util.Map;

public final class AutoSellScreen extends Screen {
    private final Screen parent;

    public AutoSellScreen(Screen parent) {
        super(Text.literal("Choose item to sell"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        if (client.player != null) {
            Map<String, ItemStack> unique = new LinkedHashMap<>();
            Map<String, Integer> counts = new LinkedHashMap<>();
            for (int i = 0; i < client.player.getInventory().size(); i++) {
                ItemStack stack = client.player.getInventory().getStack(i);
                if (stack.isEmpty()) continue;
                String id = Registries.ITEM.getId(stack.getItem()).toString();
                unique.putIfAbsent(id, stack.copy());
                counts.merge(id, stack.getCount(), Integer::sum);
            }

            int columns = 4;
            int buttonW = Math.min(130, (width - 50) / columns - 8);
            int gap = 8;
            int totalW = columns * buttonW + (columns - 1) * gap;
            int left = (width - totalW) / 2;
            int top = 68;
            int index = 0;
            for (Map.Entry<String, ItemStack> entry : unique.entrySet()) {
                if (index >= 24) break;
                final String id = entry.getKey();
                ItemStack stack = entry.getValue();
                int amount = counts.getOrDefault(id, stack.getCount());
                int col = index % columns;
                int row = index / columns;
                String title = stack.getName().getString();
                if (title.length() > 15) title = title.substring(0, 14) + "…";
                String label = title + "  x" + amount;
                addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> {
                    BypassConfig.sellItem = id;
                    BypassConfig.autoSell = true;
                    BypassConfig.save();
                    client.setScreen(parent);
                }).dimensions(left + col * (buttonW + gap), top + row * 27, buttonW, 22).build());
                index++;
            }
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("CANCEL"), b -> client.setScreen(parent))
                .dimensions(width / 2 - 90, height - 38, 180, 22).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int panelW = Math.min(610, width - 24);
        int left = (width - panelW) / 2;
        context.fill(left, 28, left + panelW, height - 20, 0xEF0B1020);
        context.fill(left, 28, left + panelW, 31, 0xFF9B65FF);
        context.drawCenteredTextWithShadow(textRenderer, "SELECT INVENTORY ITEM", width / 2, 42, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, "Bypass will send /sell <item> every 2 seconds", width / 2, 55, 0xFF9BA8C5);
        if (client.player == null || client.player.getInventory().isEmpty()) {
            context.drawCenteredTextWithShadow(textRenderer, "No inventory available", width / 2, 100, 0xFFFFFFFF);
        }
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
