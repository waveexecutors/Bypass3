package com.toodoo.bypass.gui;

import com.toodoo.bypass.BypassConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.List;
import java.util.Set;

public final class CosmeticsScreen extends Screen {
    private final Screen parent;
    private String category = "WINGS";

    private static final List<String> WING_OPTIONS = List.of("ANGEL", "DEMON", "CYBER", "BUTTERFLY", "VOID");
    private static final List<String> BANDANA_OPTIONS = List.of("RED", "BLUE", "BLACK", "PURPLE", "EMERALD");
    private static final List<String> MASK_OPTIONS = List.of("ONI", "TACTICAL", "NEON", "PHANTOM", "SKULL");
    private static final List<String> HAT_OPTIONS = List.of("CROWN", "BEANIE", "COWBOY", "HALO", "TOP HAT");

    public CosmeticsScreen(Screen parent) {
        super(Text.literal("Bypass Accessory Studio"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        String[] names = {"WINGS", "BANDANAS", "MASKS", "HATS"};
        int tabW = Math.min(112, (width - 80) / 4);
        int startX = 30;
        for (int i = 0; i < names.length; i++) {
            String next = names[i];
            addDrawableChild(ButtonWidget.builder(Text.literal(next), b -> {
                category = next;
                clearAndInit();
            }).dimensions(startX + i * (tabW + 8), 54, tabW, 22).build());
        }

        List<String> options = optionsFor(category);
        Set<String> selected = BypassConfig.getCosmetics(category);
        int left = 34;
        int top = 102;
        int colW = 140;
        for (int i = 0; i < options.size(); i++) {
            String option = options.get(i);
            String label = option + (selected.contains(option) ? "  [ON]" : "  [OFF]");
            int col = i % 2;
            int row = i / 2;
            addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> {
                BypassConfig.toggleCosmetic(category, option);
                clearAndInit();
            }).dimensions(left + col * (colW + 10), top + row * 28, colW, 22).build());
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("SAVE CONFIG"), b -> {
            BypassConfig.save();
            client.setScreen(parent);
        }).dimensions(width - 224, height - 38, 100, 22).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("BACK"), b -> client.setScreen(parent))
                .dimensions(width - 116, height - 38, 88, 22).build());
    }

    private List<String> optionsFor(String selectedCategory) {
        return switch (selectedCategory) {
            case "BANDANAS" -> BANDANA_OPTIONS;
            case "MASKS" -> MASK_OPTIONS;
            case "HATS" -> HAT_OPTIONS;
            default -> WING_OPTIONS;
        };
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Avoid the vanilla blur pipeline: it can be invoked more than once in a frame.
        context.fill(0, 0, width, height, 0xA8000000);
        context.fill(16, 18, width - 16, height - 16, 0xEF0B1020);
        context.fill(16, 18, width - 16, 21, 0xFF9B65FF);
        context.drawTextWithShadow(textRenderer, "BYPASS  /  ACCESSORY STUDIO", 32, 31, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "Choose several categories at once. Selection is saved locally.", 32, 42, 0xFF9BA8C5);

        int previewLeft = width - 255;
        int previewTop = 70;
        context.fill(previewLeft, previewTop, width - 34, height - 58, 0xA5162036);
        context.drawCenteredTextWithShadow(textRenderer, "PLAYER PREVIEW", previewLeft + 110, previewTop + 12, 0xFFFFFFFF);
        if (client.player != null) {
            InventoryScreen.drawEntity(context, previewLeft + 30, previewTop + 36, previewLeft + 190,
                    Math.min(height - 68, previewTop + 250), 74, 0.0625f, mouseX, mouseY, client.player);
        }

        int infoY = Math.max(previewTop + 250, height - 112);
        context.drawTextWithShadow(textRenderer, "ACTIVE COSMETICS", previewLeft + 12, infoY, 0xFFC9B4FF);
        int line = infoY + 14;
        for (String type : List.of("WINGS", "BANDANAS", "MASKS", "HATS")) {
            Set<String> choices = BypassConfig.getCosmetics(type);
            String value = choices.isEmpty() ? "—" : String.join(", ", choices);
            if (value.length() > 26) value = value.substring(0, 25) + "…";
            context.drawTextWithShadow(textRenderer, type + ": " + value, previewLeft + 12, line, 0xFFE1E7F5);
            line += 12;
        }

        context.drawTextWithShadow(textRenderer, "Selections are saved locally; accessory rendering is not included yet.", 32, height - 30, 0xFF7785A4);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
