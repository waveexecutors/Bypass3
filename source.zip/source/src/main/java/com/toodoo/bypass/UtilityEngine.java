package com.toodoo.bypass;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.text.Text;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Client-side helpers. All block scans are restricted to data received by the client. */
public final class UtilityEngine {
    private static long ticks;
    private static int lastTotemCount = -1;

    private UtilityEngine() {}

    public static void tick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        ticks++;

        if (BypassConfig.autoSprint && client.options.forwardKey.isPressed() && !client.player.isSneaking()) {
            client.player.setSprinting(true);
        }

        if (BypassConfig.autoFarm && ticks % 12 == 0) {
            plantOneNearbyCrop(client);
        }

        if (BypassConfig.oreScanner && ticks % 100 == 0) {
            scanForOres(client);
        }

        if (BypassConfig.baseFinder && ticks % 120 == 0) {
            scanForStorage(client);
        }

        if (BypassConfig.autoSell && ticks % 40 == 0) {
            sellSelectedItem(client);
        }

        if (BypassConfig.totemAlert && ticks % 40 == 0) {
            checkTotems(client);
        }
    }

    private static void plantOneNearbyCrop(MinecraftClient client) {
        PlayerInventory inventory = client.player.getInventory();
        int seedSlot = findSeedSlot(inventory);
        if (seedSlot < 0 || client.interactionManager == null) return;

        int previousSlot = inventory.getSelectedSlot();
        inventory.setSelectedSlot(seedSlot);
        BlockPos origin = client.player.getBlockPos();
        World world = client.world;

        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                for (int dy = -2; dy <= 2; dy++) {
                    BlockPos cropPos = origin.add(dx, dy, dz);
                    BlockPos soilPos = cropPos.down();
                    if (world.getBlockState(soilPos).isOf(Blocks.FARMLAND) && world.getBlockState(cropPos).isAir()) {
                        Vec3d hitPoint = new Vec3d(soilPos.getX() + 0.5, soilPos.getY() + 1.0, soilPos.getZ() + 0.5);
                        BlockHitResult hit = new BlockHitResult(hitPoint, Direction.UP, soilPos, false);
                        client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, hit);
                        inventory.setSelectedSlot(previousSlot);
                        return;
                    }
                }
            }
        }
        inventory.setSelectedSlot(previousSlot);
    }

    private static int findSeedSlot(PlayerInventory inventory) {
        Item[] seeds = {Items.WHEAT_SEEDS, Items.CARROT, Items.POTATO, Items.BEETROOT_SEEDS,
                Items.MELON_SEEDS, Items.PUMPKIN_SEEDS};
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = inventory.getStack(slot);
            for (Item seed : seeds) {
                if (!stack.isEmpty() && stack.isOf(seed)) return slot;
            }
        }
        return -1;
    }

    private static void scanForOres(MinecraftClient client) {
        BlockPos origin = client.player.getBlockPos();
        List<BlockPos> found = new ArrayList<>();
        int radius = 14;
        int vertical = 9;
        for (int x = -radius; x <= radius; x++) {
            for (int y = -vertical; y <= vertical; y++) {
                for (int z = -radius; z <= radius; z++) {
                    BlockPos pos = origin.add(x, y, z);
                    if (isOre(client.world.getBlockState(pos).getBlock())) found.add(pos.toImmutable());
                }
            }
        }
        found.sort(Comparator.comparingDouble(p -> client.player.squaredDistanceTo(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5)));
        if (found.isEmpty()) {
            tell(client, "Ore scan: no known ore blocks in the nearby loaded area.");
            return;
        }
        StringBuilder out = new StringBuilder("Ore scan (nearest): ");
        for (int i = 0; i < Math.min(3, found.size()); i++) {
            BlockPos p = found.get(i);
            if (i > 0) out.append(" | ");
            out.append(p.getX()).append(' ').append(p.getY()).append(' ').append(p.getZ());
        }
        tell(client, out.toString());
    }

    private static boolean isOre(Block block) {
        return block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE
                || block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE
                || block == Blocks.ANCIENT_DEBRIS || block == Blocks.GOLD_ORE
                || block == Blocks.DEEPSLATE_GOLD_ORE || block == Blocks.IRON_ORE
                || block == Blocks.DEEPSLATE_IRON_ORE || block == Blocks.REDSTONE_ORE
                || block == Blocks.DEEPSLATE_REDSTONE_ORE || block == Blocks.LAPIS_ORE
                || block == Blocks.DEEPSLATE_LAPIS_ORE;
    }

    private static void scanForStorage(MinecraftClient client) {
        BlockPos origin = client.player.getBlockPos();
        List<BlockPos> found = new ArrayList<>();
        int radius = 24;
        int vertical = 8;
        for (int x = -radius; x <= radius; x++) {
            for (int y = -vertical; y <= vertical; y++) {
                for (int z = -radius; z <= radius; z++) {
                    BlockPos pos = origin.add(x, y, z);
                    Block block = client.world.getBlockState(pos).getBlock();
                    if (block == Blocks.CHEST || block == Blocks.TRAPPED_CHEST || block == Blocks.BARREL
                            || block == Blocks.SHULKER_BOX || block == Blocks.WHITE_SHULKER_BOX
                            || block == Blocks.BLACK_SHULKER_BOX || block == Blocks.BLUE_SHULKER_BOX
                            || block == Blocks.RED_SHULKER_BOX || block == Blocks.GREEN_SHULKER_BOX) {
                        found.add(pos.toImmutable());
                    }
                }
            }
        }
        found.sort(Comparator.comparingDouble(p -> client.player.squaredDistanceTo(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5)));
        if (found.isEmpty()) {
            tell(client, "Base radar: no nearby storage blocks detected in loaded client data.");
            return;
        }
        BlockPos p = found.get(0);
        double distance = Math.sqrt(client.player.squaredDistanceTo(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5));
        tell(client, String.format("Base radar: storage at %d %d %d (%.1fm)", p.getX(), p.getY(), p.getZ(), distance));
    }

    private static void sellSelectedItem(MinecraftClient client) {
        String selected = BypassConfig.sellItem;
        if (selected == null || selected.isBlank() || client.player.networkHandler == null) return;
        boolean stillHasItem = false;
        for (int i = 0; i < client.player.getInventory().size(); i++) {
            ItemStack stack = client.player.getInventory().getStack(i);
            if (!stack.isEmpty() && Registries.ITEM.getId(stack.getItem()).toString().equals(selected)) {
                stillHasItem = true;
                break;
            }
        }
        if (!stillHasItem) return;
        String commandArgument = selected.contains(":") ? selected.substring(selected.indexOf(':') + 1) : selected;
        client.player.networkHandler.sendChatCommand("sell " + commandArgument);
    }

    private static void checkTotems(MinecraftClient client) {
        int count = 0;
        for (int i = 0; i < client.player.getInventory().size(); i++) {
            ItemStack stack = client.player.getInventory().getStack(i);
            if (stack.isOf(Items.TOTEM_OF_UNDYING)) count += stack.getCount();
        }
        if (lastTotemCount > 0 && count == 0) {
            tell(client, "WARNING: no Totem of Undying left in your inventory.");
        }
        lastTotemCount = count;
    }

    private static void tell(MinecraftClient client, String message) {
        if (client.player != null) client.player.sendMessage(Text.literal("§8[§5Bypass§8] §f" + message), false);
    }
}
