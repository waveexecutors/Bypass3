package com.toodoo.bypass.gui;

import com.toodoo.bypass.BypassConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class BypassClickGui extends Screen {
    private enum Tab { MINING, FARMING, SMP, MOVEMENT, MISC }

    private Tab activeTab = Tab.MINING;

    public BypassClickGui() {
        super(Text.literal("Bypass"));
    }

    @Override
    protected void init() {
        int panelW = Math.min(470, width - 24);
        int left = (width - panelW) / 2;
        int top = Math.max(18, (height - 350) / 2);
        int tabY = top + 48;
        String[] labels = {"MINING", "FARMING", "SMP", "MOVEMENT", "MISC"};
        Tab[] tabs = Tab.values();
        int tabW = (panelW - 36) / 5;
        for (int i = 0; i < tabs.length; i++) {
            final Tab next = tabs[i];
            int x = left + 18 + i * tabW;
            addDrawableChild(ButtonWidget.builder(Text.literal(labels[i]), b -> {
                activeTab = next;
                clearAndInit();
            }).dimensions(x, tabY, tabW - 4, 22).build());
        }

        int startY = top + 94;
        int colW = (panelW - 54) / 2;
        switch (activeTab) {
            case MINING -> {
                addToggle(left + 18, startY, colW, "Ore Scanner", BypassConfig.oreScanner, () -> BypassConfig.oreScanner = !BypassConfig.oreScanner);
                addInfo(left + 18, startY + 34, "Scans nearby client-known ore blocks.");
                addInfo(left + 18, startY + 52, "Cannot reveal blocks hidden by server anti-xray.");
            }
            case FARMING -> {
                addToggle(left + 18, startY, colW, "Auto Farm Planter", BypassConfig.autoFarm, () -> BypassConfig.autoFarm = !BypassConfig.autoFarm);
                addInfo(left + 18, startY + 34, "Plants one crop at a time on nearby farmland.");
                addInfo(left + 18, startY + 52, "Seeds must be in your hotbar; farmland must exist.");
            }
            case SMP -> {
                addToggle(left + 18, startY, colW, "Base / Storage Radar", BypassConfig.baseFinder, () -> BypassConfig.baseFinder = !BypassConfig.baseFinder);
                addToggle(left + 18 + colW + 12, startY, colW, "Totem Alert", BypassConfig.totemAlert, () -> BypassConfig.totemAlert = !BypassConfig.totemAlert);
                addButton(left + 18, startY + 38, colW, "Auto Sell: " + (BypassConfig.autoSell ? "ON" : "OFF"), () -> {
                    if (BypassConfig.autoSell) {
                        BypassConfig.autoSell = false;
                        BypassConfig.save();
                        clearAndInit();
                    } else {
                        client.setScreen(new AutoSellScreen(this));
                    }
                });
                addInfo(left + 18, startY + 78, "Selected item: " + (BypassConfig.sellItem.isBlank() ? "none" : BypassConfig.sellItem));
                addInfo(left + 18, startY + 96, "Sends /sell <item> every 2 seconds while item exists.");
                addInfo(left + 18, startY + 114, "Command syntax depends on the server plugin.");
            }
            case MOVEMENT -> {
                addToggle(left + 18, startY, colW, "Auto Sprint", BypassConfig.autoSprint, () -> BypassConfig.autoSprint = !BypassConfig.autoSprint);
                addInfo(left + 18, startY + 34, "Sprints while moving forward and not sneaking.");
            }
            case MISC -> {
                addToggle(left + 18, startY, colW, "Coordinates HUD", BypassConfig.coordsHud, () -> BypassConfig.coordsHud = !BypassConfig.coordsHud);
                addInfo(left + 18, startY + 34, "Shows your current XYZ in the HUD.");
            }
        }

        addButton(left + 18, top + 292, panelW - 36, "ACCESSORY STUDIO  →", () -> client.setScreen(new CosmeticsScreen(this)));
        addButton(left + 18, top + 320, panelW - 36, "CLOSE", () -> client.setScreen(null));
    }

    private void addToggle(int x, int y, int w, String label, boolean enabled, Runnable action) {
        addButton(x, y, w, label + (enabled ? "  [ON]" : "  [OFF]"), () -> {
            action.run();
            BypassConfig.save();
            clearAndInit();
        });
    }

    private void addButton(int x, int y, int w, String label, Runnable action) {
        addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> action.run())
                .dimensions(x, y, w, 22).build());
    }

    private void addInfo(int x, int y, String message) {
        addDrawableChild(ButtonWidget.builder(Text.literal(message), b -> {})
                .dimensions(x, y, Math.min(420, width - x - 12), 18).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Avoid the vanilla blur pipeline: it can be invoked more than once in a frame.
        context.fill(0, 0, width, height, 0xA8000000);
        int panelW = Math.min(470, width - 24);
        int left = (width - panelW) / 2;
        int top = Math.max(18, (height - 350) / 2);
        context.fill(left, top, left + panelW, top + 354, 0xEF0B1020);
        context.fill(left, top, left + panelW, top + 3, 0xFF9B65FF);
        context.drawTextWithShadow(textRenderer, "BYPASS", left + 18, top + 14, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, "CLIENT UTILITY SUITE  /  1.21.11", left + 92, top + 15, 0xFF9BA8C5);
        context.drawTextWithShadow(textRenderer, "RIGHT SHIFT  •  CLICKGUI", left + 18, top + 340, 0xFF747F9D);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
