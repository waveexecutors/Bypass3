package com.toodoo.bypass;

import com.toodoo.bypass.gui.BypassClickGui;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class BypassClient implements ClientModInitializer {
    public static final String MOD_ID = "bypass";
    public static final Logger LOGGER = LoggerFactory.getLogger("Bypass");

    private static KeyBinding openGui;

    @Override
    public void onInitializeClient() {
        BypassConfig.load();

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(MOD_ID, "general"));
        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.bypass.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                category
        ));

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            var client = net.minecraft.client.MinecraftClient.getInstance();
            if (BypassConfig.coordsHud && client.player != null && client.world != null) {
                String xyz = String.format("XYZ  %d / %d / %d", client.player.getBlockX(), client.player.getBlockY(), client.player.getBlockZ());
                drawContext.fill(8, 8, 142, 27, 0xA80B1020);
                drawContext.fill(8, 8, 10, 27, 0xFF9B65FF);
                drawContext.drawTextWithShadow(client.textRenderer, xyz, 15, 14, 0xFFFFFFFF);
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGui.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new BypassClickGui());
                }
            }
            UtilityEngine.tick(client);
        });

        LOGGER.info("Bypass client initialized for Minecraft 1.21.11");
    }
}
